package numerotiedustelu;
 
import java.util.*;
 
public class NumeroJaOsoitePalvelu {
 
    public NumeroJaOsoitePalvelu() {
    }
 
    public void lisaaNumero(String nimi, String numero) {

    }
 
    public Collection<String> haeNumerot(String nimi) {
        return null;
    }
 
    public String haeNimi(String numero) {
        return null;
    }
 
    public void lisaaOsoite(String nimi, String katu, String kaupunki) {

    }
 
    public Henkilo haeNimenPerusteella(String nimi) {

        return null;
    }
 
 
    public void poista(String nimi) {

    }
 
}